I have edited the code to perform the bonus where the keyboard reflects the state of the keys.
